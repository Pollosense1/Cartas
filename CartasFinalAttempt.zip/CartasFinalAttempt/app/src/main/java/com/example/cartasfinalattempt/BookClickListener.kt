package com.example.cartasfinalattempt

interface BookClickListener
{
    fun onClick(book: Book)
}