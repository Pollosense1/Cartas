package com.example.cartas

interface BookClickListener
{
    fun onClick(book: Book)
}