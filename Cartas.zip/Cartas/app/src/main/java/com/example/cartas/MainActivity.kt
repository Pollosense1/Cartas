package com.example.cartas

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cartas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), BookClickListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        populateBooks()

        val mainActivity = this
        binding.recyclerview.apply {
            layoutManager = GridLayoutManager(applicationContext, 3)
            adapter = CardAdapter(bookList, mainActivity)
        }
    }

    override fun onClick(book: Book) {
        val intent = Intent(applicationContext, DetailActivity::class.java)
        intent.putExtra(BOOK_ID_EXTRA, book.id)
        startActivity(intent)
    }

    private fun populateBooks() {
        val book1 = Book(
            R.drawable.uno,
            title = "Krenko, Mob boss",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book1)

        val book2 = Book(
            R.drawable.dos,
            title = "The Scarab god",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book2)

        val book3 = Book(
            R.drawable.tres,
            title = "Jodah, Archmage Eternal",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book3)

        val book4 = Book(
            R.drawable.cuatro,
            title = "Hajar, Loyal Bodyguard",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book4)

        val book5 = Book(
            R.drawable.cinco,
            title = "Atraxa, Praetors' Voice",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book5)

        val book6 = Book(
            R.drawable.seis,
            title = "Zurgo Helmsmasher",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book6)

        val book7 = Book(
            R.drawable.siete,
            title = "Rasputin, the Oneiromancer",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book7)

        val book8 = Book(
            R.drawable.ocho,
            title = "Avacyn, Angel of Hope",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book8)

        val book9 = Book(
            R.drawable.nueve,
            title = "Kruphix, God of Horizons",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book9)

        val book10 = Book(
            R.drawable.diez,
            title = "Dihada, Binder of Wills",
            author = "Criatura legendaria",
            description = "Lorem ipsum"
        )
        bookList.add(book10)

        bookList.add(book1)
        bookList.add(book2)
        bookList.add(book3)
        bookList.add(book4)
        bookList.add(book5)
        bookList.add(book6)
        bookList.add(book7)
        bookList.add(book8)
        bookList.add(book9)
        bookList.add(book10)
        bookList.add(book1)
        bookList.add(book2)
        bookList.add(book3)
        bookList.add(book4)
        bookList.add(book5)
        bookList.add(book6)
        bookList.add(book7)
        bookList.add(book8)
        bookList.add(book9)
        bookList.add(book10)
    }
}